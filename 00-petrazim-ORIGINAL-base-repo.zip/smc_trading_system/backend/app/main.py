
"""
SMC Multi-Bot Automated Trading System
Principal Algorithmic Trading Engine
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import structlog
from app.config import get_settings
from app.routers import webhook_router, trades_router, bots_router, dashboard_router
from app.database import engine, Base

settings = get_settings()
logger = structlog.get_logger()

# Connection manager for WebSocket broadcasting
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except:
                pass

manager = ConnectionManager()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler."""
    logger.info("app_startup", version=settings.VERSION)

    # Create database tables
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    yield

    logger.info("app_shutdown")
    await engine.dispose()

app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description="""
    Premium Smart Money Concepts (SMC) Multi-Bot Automated Trading System.

    Features:
    - 5 Distinct SMC Trading Bots
    - Multi-Timeframe Alignment Engine (1D→4H→1H→15M→5M)
    - Human-in-the-Loop & Fully Autonomous Execution
    - TradingView Webhook Integration
    - Real-time Dashboard & Analytics
    - Risk Management & Portfolio Safeguards
    """,
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(webhook_router)
app.include_router(trades_router)
app.include_router(bots_router)
app.include_router(dashboard_router)

@app.get("/")
async def root():
    return {
        "app": settings.APP_NAME,
        "version": settings.VERSION,
        "status": "operational",
        "endpoints": {
            "api_docs": "/api/docs",
            "webhook": "/webhook/tradingview",
            "trades": "/trades",
            "bots": "/bots",
            "dashboard": "/dashboard/stats",
            "websocket": "/ws"
        }
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": __import__("datetime").datetime.utcnow().isoformat()}

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket for real-time trade updates and dashboard data."""
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            # Handle client messages (subscriptions, etc.)
            if data.get("action") == "subscribe":
                await websocket.send_json({
                    "type": "subscription_confirmed",
                    "channel": data.get("channel", "all")
                })
    except WebSocketDisconnect:
        manager.disconnect(websocket)
    except Exception as e:
        logger.error("websocket_error", error=str(e))
        manager.disconnect(websocket)

@app.get("/api/system-info")
async def system_info():
    """Get system configuration and bot status overview."""
    return {
        "app_name": settings.APP_NAME,
        "version": settings.VERSION,
        "debug": settings.DEBUG,
        "default_risk": settings.DEFAULT_RISK_PERCENT,
        "default_rr": settings.DEFAULT_RR_RATIO,
        "max_daily_trades": settings.MAX_DAILY_TRADES,
        "max_portfolio_exposure": settings.MAX_PORTFOLIO_EXPOSURE,
        "features": [
            "5_SMC_Bots",
            "MTF_Alignment",
            "Human_in_Loop",
            "Fully_Autonomous",
            "TradingView_Integration",
            "Risk_Management",
            "Batch_Processing",
            "Analytics_Feedback_Loop"
        ]
    }
