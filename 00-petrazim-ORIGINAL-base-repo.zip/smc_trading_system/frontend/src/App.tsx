
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Layout } from './components/Layout';
import { DashboardPage } from './pages/Dashboard';
import { TradesPage } from './pages/Trades';
import { BotsPage } from './pages/Bots';

function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<DashboardPage />} />
          <Route path="/trades" element={<TradesPage />} />
          <Route path="/bots" element={<BotsPage />} />
          <Route path="/analytics" element={<DashboardPage />} />
          <Route path="/risk" element={<DashboardPage />} />
          <Route path="/settings" element={<BotsPage />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}

export default App;
