/**
 * Add to the `extend.colors` block of the existing tailwind.config.js
 * (from v2's frontend) — do not replace the file, merge this in
 * alongside the existing smc-* dark-theme tokens, which stay for the
 * Trade console.
 */
module.exports = {
  corporate: {
    bg: '#EAEAF4',        // main canvas — Learn/Insights/Community/Explore/nav chrome
    hero: '#1A3364',      // hero blocks, primary nav bar, footer
    'hero-light': '#26417d', // hover/lighter variant of hero blue, derived for interactive states
    accent: '#FF7A00',    // CTAs, active tab indicator, badges
    'accent-hover': '#e66d00',
    'text-on-hero': '#FFFFFF',
    'text-on-bg': '#1A1A2E',
  },
};
