import { useState } from 'react';

/**
 * RegistrationGateCard — collapsible "Register to Unlock" pattern from
 * the Academy build. Captures Name/Email/Phone before any paid content
 * opens, shown on the pricing/access page before checkout.
 */
export function RegistrationGateCard({
  onSubmit,
}: {
  onSubmit: (data: { name: string; email: string; phone: string }) => void;
}) {
  const [expanded, setExpanded] = useState(true);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');

  return (
    <div className="bg-smc-card border border-smc-border rounded-xl overflow-hidden">
      <button
        onClick={() => setExpanded((e) => !e)}
        className="w-full flex items-center justify-between p-4 text-left"
      >
        <span className="font-medium text-white">Register to Unlock Access</span>
        <span className="text-gray-400 text-sm">{expanded ? '−' : '+'}</span>
      </button>

      {expanded && (
        <div className="p-4 pt-0 space-y-3">
          <input
            placeholder="Full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full bg-smc-dark border border-smc-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-smc-accent"
          />
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full bg-smc-dark border border-smc-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-smc-accent"
          />
          <input
            type="tel"
            placeholder="Phone (with country code)"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="w-full bg-smc-dark border border-smc-border rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-smc-accent"
          />
          <button
            onClick={() => onSubmit({ name, email, phone })}
            disabled={!name || !email || !phone}
            className="w-full bg-smc-accent text-white font-medium py-2.5 rounded-lg text-sm hover:opacity-90 transition disabled:opacity-40"
          >
            Continue
          </button>
        </div>
      )}
    </div>
  );
}
