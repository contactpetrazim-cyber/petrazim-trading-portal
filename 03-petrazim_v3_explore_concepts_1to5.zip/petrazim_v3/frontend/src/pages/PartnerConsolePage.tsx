import { RoleBadge } from '../components/RoleBadge';
import { useAuth } from '../hooks/useAuth';

/**
 * Partner/Investor console — scaffold for v3 Phase 1. Full content
 * (fund contribution tracking, referral/commission dashboard tied to
 * Phase 2's payment + referral-code system) comes later.
 */
export function PartnerConsolePage() {
  const { user } = useAuth();
  if (!user) return null;

  return (
    <div className="min-h-screen bg-smc-dark text-white p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Partner Console</h1>
        <RoleBadge user={user} />
      </div>
      <div className="bg-smc-card border border-smc-border rounded-xl p-6 text-gray-400">
        Welcome, {user.full_name}. This console will show your fund
        contributions and — once Phase 2's referral/commission system is
        built — your partner referral dashboard.
      </div>
    </div>
  );
}
