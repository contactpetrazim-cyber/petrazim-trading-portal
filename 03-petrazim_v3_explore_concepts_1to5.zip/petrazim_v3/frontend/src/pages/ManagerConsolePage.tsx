import { RoleBadge } from '../components/RoleBadge';
import { useAuth } from '../hooks/useAuth';

/**
 * Fund Manager console — scaffold for v3 Phase 1. Full content
 * (managed accounts, allocation views, performance reporting per
 * client) is a later phase; this establishes the route, auth guard,
 * and layout shell so subsequent phases have a home to build into.
 */
export function ManagerConsolePage() {
  const { user } = useAuth();
  if (!user) return null;

  return (
    <div className="min-h-screen bg-smc-dark text-white p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Fund Manager Console</h1>
        <RoleBadge user={user} />
      </div>
      <div className="bg-smc-card border border-smc-border rounded-xl p-6 text-gray-400">
        Welcome, {user.full_name}. This console will show managed accounts,
        allocation views, and per-client performance reporting — coming in
        a later v3 phase, built on top of this authenticated shell.
      </div>
    </div>
  );
}
