"""
Auth Core — password hashing, JWT issuance/verification, role guards
========================================================================

One login for all four roles. On successful login, the JWT encodes the
user's role; the frontend reads that to redirect (ROLE_LANDING_ROUTE),
and every protected backend route uses require_role() to check it
server-side too — the frontend redirect is a convenience, never the
actual security boundary.

SUPER ADMIN SAFETY: require_super_admin() checks BOTH role == SUPER_ADMIN
AND is_super_admin_seed == True. This means granting someone the
super_admin role alone (e.g. by a bug or a compromised admin session)
is not sufficient to unlock super-admin-only actions — only the
specifically seeded account can. See migrations/002_seed_super_admin.sql.
"""

from __future__ import annotations

import os
from datetime import datetime, timedelta, timezone
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models.user import User, UserRole, UserStatus

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")

# Reuses the existing SECRET_KEY / ALGORITHM from app.config — do not
# introduce a second secret for this. If SECRET_KEY is still the
# placeholder default from config.py, refuse to issue tokens rather
# than silently signing them with a known-public key.
_PLACEHOLDER_SECRET = "smc-super-secret-key-change-in-production"


def _get_secret() -> str:
    from app.config import get_settings
    secret = get_settings().SECRET_KEY
    if secret == _PLACEHOLDER_SECRET:
        raise RuntimeError(
            "SECRET_KEY is still the placeholder value. Set a real secret "
            "(env var SECRET_KEY) before issuing any auth tokens — this is "
            "not safe to run with the default in any environment real "
            "users can reach."
        )
    return secret


ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24h; access-window enforcement is separate (Phase 2)


def hash_password(plain_password: str) -> str:
    return pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(user: User) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    payload = {
        "sub": str(user.id),
        "role": user.role.value,
        "is_super_admin_seed": user.is_super_admin_seed,
        "exp": expire,
    }
    return jwt.encode(payload, _get_secret(), algorithm=ALGORITHM)


async def get_current_user(
    token: str = Depends(oauth2_scheme), db: AsyncSession = Depends(get_db)
) -> User:
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, _get_secret(), algorithms=[ALGORITHM])
        user_id: Optional[str] = payload.get("sub")
        if user_id is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    result = await db.execute(select(User).where(User.id == user_id))
    user = result.scalar_one_or_none()
    if user is None:
        raise credentials_exception
    if user.status == UserStatus.SUSPENDED:
        raise HTTPException(status_code=403, detail="Account suspended")
    return user


def require_role(*allowed_roles: UserRole):
    """Dependency factory: require_role(UserRole.ADMIN, UserRole.SUPER_ADMIN)"""
    async def checker(user: User = Depends(get_current_user)) -> User:
        if user.role not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Requires one of: {[r.value for r in allowed_roles]}",
            )
        return user
    return checker


async def require_super_admin(user: User = Depends(get_current_user)) -> User:
    """Stricter than require_role(SUPER_ADMIN) — also checks the seed flag.
    Use this specifically for account-management power (add/remove
    admins, managers, traders, partners), not for general admin actions."""
    if user.role != UserRole.SUPER_ADMIN or not user.is_super_admin_seed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Super Admin privileges required",
        )
    return user
