"""
User & Role Model — v3 Foundation
====================================

Adds the four-role system on top of the existing trading engine:
Trader, Fund Manager, Partner (brings funds for trading / investor),
Admin, and Super Admin. One users table, one login, role decides where
you land and what you can do — everything else (payments, meetings,
admin console) checks against this.

ROLE HIERARCHY (for authorization checks, not display order):
  super_admin > admin > fund_manager > partner > trader

Only ONE super_admin should exist in normal operation (Adekunle Oke,
per the v3 spec) — enforced at the application layer in core/auth.py,
not the database, so a future genuine need for a second super admin
isn't blocked by a hard schema constraint.
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Enum, String
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class UserRole(enum.Enum):
    TRADER = "trader"
    FUND_MANAGER = "fund_manager"
    PARTNER = "partner"          # investor / brings funds for trading
    ADMIN = "admin"
    SUPER_ADMIN = "super_admin"


class UserStatus(enum.Enum):
    PENDING = "pending"          # registered, not yet activated/paid
    ACTIVE = "active"
    SUSPENDED = "suspended"
    ACCESS_EXPIRED = "access_expired"   # paid access window lapsed (Phase 2)


# Role badge colors — the "watermark" spec item. Kept here, next to the
# role enum, so the frontend and backend can never disagree about which
# color maps to which role.
ROLE_BADGE_COLOR = {
    UserRole.TRADER: "#3b82f6",        # blue
    UserRole.FUND_MANAGER: "#8b5cf6",  # purple
    UserRole.PARTNER: "#f59e0b",       # amber
    UserRole.ADMIN: "#ef4444",         # red
    UserRole.SUPER_ADMIN: "#111827",   # near-black, deliberately distinct
}

# Where each role lands immediately after login.
ROLE_LANDING_ROUTE = {
    UserRole.TRADER: "/dashboard",
    UserRole.FUND_MANAGER: "/manager",
    UserRole.PARTNER: "/partner",
    UserRole.ADMIN: "/admin",
    UserRole.SUPER_ADMIN: "/admin",
}


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False, index=True)
    phone = Column(String(50), nullable=True)
    full_name = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)

    role = Column(Enum(UserRole), nullable=False, default=UserRole.TRADER)
    status = Column(Enum(UserStatus), nullable=False, default=UserStatus.PENDING)

    # Set true only for the single seeded Super Admin account. Checked
    # alongside role == SUPER_ADMIN in core/auth.py before granting any
    # super-admin-only action, so a role field alone can never be enough.
    is_super_admin_seed = Column(Boolean, nullable=False, default=False)

    created_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)
    created_by = Column(UUID(as_uuid=True), nullable=True)   # which admin/super-admin created this account, if any
    last_login_at = Column(DateTime(timezone=True), nullable=True)
