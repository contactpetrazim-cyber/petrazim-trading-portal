"""
Access & Payment Models
==========================

Adapted from patterns proven in Petrazim Academy V3 (Lovable/Supabase
build), rebuilt for this stack (FastAPI/Postgres) and this platform's
own role system — a Trader's paid access is to trading tools/signals,
not training content, so the tier *content* differs even though the
tier *structure* (Essential/Professional/Executive + duration passes)
is deliberately kept identical to what you already validated works.

ONE CODE FIELD, THREE MEANINGS — reused directly from the Academy:
A single `redeem_code()` call handles promo codes, partner/referral
codes, AND corporate seat codes (e.g. a Fund Manager sponsoring
multiple Trader seats) — same simplification that worked there.
"""

from __future__ import annotations

import enum
import uuid
from datetime import datetime

from sqlalchemy import Boolean, Column, DateTime, Enum, Float, ForeignKey, Integer, String
from sqlalchemy.dialects.postgresql import UUID

from app.database import Base


class AccessTier(enum.Enum):
    ESSENTIAL = "essential"
    PROFESSIONAL = "professional"
    EXECUTIVE = "executive"


class DurationPassType(enum.Enum):
    ONE_DAY = "one_day"
    HALF_DAY = "half_day"
    AM = "am"
    PM = "pm"
    THREE_HOUR_REFRESH = "three_hour_refresh"
    ONE_MODULE = "one_module"          # here: one bot/tool, not one training pillar


class CodeType(enum.Enum):
    PROMO = "promo"                    # admin-issued, free/discounted access
    PARTNER_REFERRAL = "partner_referral"   # tags a paid signup to a partner for commission
    CORPORATE_SEAT = "corporate_seat"  # one of N seats a Fund Manager/Partner purchased for others


class PaymentProvider(enum.Enum):
    STRIPE = "stripe"
    PAYSTACK = "paystack"


class PaymentStatus(enum.Enum):
    PENDING = "pending"
    SUCCEEDED = "succeeded"
    FAILED = "failed"
    REFUNDED = "refunded"


# --- Duration pass catalogue: your exact figures, both currencies ---
# Kept as data here (not hardcoded in the router) so pricing changes
# are a one-place edit. "essential_tier_equivalent" notes which
# AccessTier-level content each pass unlocks.
DURATION_PASS_CATALOGUE = {
    DurationPassType.ONE_DAY: {
        "label": "One-Day Pass", "hours": 24,
        "ngn": 50000, "usd": 85, "tier": AccessTier.ESSENTIAL,
    },
    DurationPassType.HALF_DAY: {
        "label": "Half-Day Pass", "hours": 4,
        "ngn": 25000, "usd": 45, "tier": AccessTier.ESSENTIAL,
    },
    DurationPassType.AM: {
        "label": "AM Pass", "hours": 4,
        "ngn": 15000, "usd": 25, "tier": AccessTier.ESSENTIAL,
    },
    DurationPassType.PM: {
        "label": "PM Pass", "hours": 4,
        "ngn": 15000, "usd": 25, "tier": AccessTier.ESSENTIAL,
    },
    DurationPassType.THREE_HOUR_REFRESH: {
        "label": "3-HR Refresh", "hours": 3,
        "ngn": 10000, "usd": 10, "tier": AccessTier.ESSENTIAL,
    },
    DurationPassType.ONE_MODULE: {
        "label": "One Module", "hours": 72,   # 3-day window
        "ngn": 100000, "usd": 25, "tier": AccessTier.ESSENTIAL,
    },
}


class UserAccess(Base):
    """One row per active/historical access grant for a user — a paid
    subscription, a duration pass, or a redeemed code all create one of
    these. The Weekly Review / Monte Carlo / dashboard routes check
    this table (via a simple "is this user currently entitled?" query),
    not the payment table directly."""
    __tablename__ = "user_access"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)

    tier = Column(Enum(AccessTier), nullable=False)
    granted_via = Column(String(50), nullable=False)   # 'payment' | 'promo_code' | 'referral_code' | 'corporate_seat' | 'admin_grant'
    duration_pass_type = Column(Enum(DurationPassType), nullable=True)  # null if it's a full subscription, not a pass

    starts_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)
    expires_at = Column(DateTime(timezone=True), nullable=False)
    is_active = Column(Boolean, nullable=False, default=True)

    created_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)


class AccessCode(Base):
    """Single table for all three code types — promo, referral, corporate seat.
    Mirrors the Academy's single-field redemption pattern on the backend too,
    not just the frontend input."""
    __tablename__ = "access_codes"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code = Column(String(32), unique=True, nullable=False, index=True)
    code_type = Column(Enum(CodeType), nullable=False)

    tier_granted = Column(Enum(AccessTier), nullable=False)
    duration_hours = Column(Integer, nullable=False, default=24 * 30)  # default 30 days

    # For corporate seats: which Fund Manager/Partner purchased the batch.
    # For partner referrals: which partner earns commission on this signup.
    issued_by_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)

    max_redemptions = Column(Integer, nullable=False, default=1)   # corporate seats: 1 each; promo: could be >1
    redemption_count = Column(Integer, nullable=False, default=0)

    expires_at = Column(DateTime(timezone=True), nullable=True)   # unredeemed codes can expire (60-day pattern)
    created_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)


class Payment(Base):
    __tablename__ = "payments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)

    provider = Column(Enum(PaymentProvider), nullable=False)
    provider_reference = Column(String(255), nullable=True)   # Stripe/Paystack session or charge id
    status = Column(Enum(PaymentStatus), nullable=False, default=PaymentStatus.PENDING)

    amount = Column(Float, nullable=False)
    currency = Column(String(3), nullable=False)   # 'NGN' or 'USD'
    tier_purchased = Column(Enum(AccessTier), nullable=True)
    duration_pass_type = Column(Enum(DurationPassType), nullable=True)
    seat_count = Column(Integer, nullable=True)    # >1 for corporate purchases

    created_at = Column(DateTime(timezone=True), nullable=False, default=datetime.utcnow)
